% Algorithm to analyze textural/spatial distribution features of the
% nucleus.
% Revised 03/02/2017 by Amy Chang (Marshall Lab, UCSF)

load('WT_celltexture.mat')

%Textural calculations (Haralick features).

for a = 1:length(measurements)
    NucImage = measurements(a).NucImage;
    NucMask = measurements(a).NucMask;
    NucImageNoBG = NucImage;
    NucImageNoBG(NucMask == 0) = 0;
    measurements(a).NucImageNoBG = NucImageNoBG;
    NucImageFull = NucImage;
    NucImageFull(NucMask == 0) = 65535;                   %set bg pixels to 65536 so they show up in (16, 16) of the GSCM; true low bin interacting pixels are revealed in (1,1)
    K = unique(NucImageNoBG);
    minpixel = K(2);
    maxpixel = max(K);
    offsets = [0 1; -1 1;-1 0;-1 -1];
    glcmsFull = graycomatrix(NucImageFull, 'NumLevel', 16, 'GrayLimits', [minpixel maxpixel], 'Symmetric', true, 'Offset', offsets);
    glcmsnoBG = graycomatrix(NucImageNoBG, 'NumLevel', 16, 'GrayLimits', [minpixel maxpixel], 'Symmetric', true, 'Offset', offsets);   
    glcmsTrue = glcmsnoBG;
    for b = 1:4
        glcmsTrue(1,1,b) = glcmsFull(1,1,b);
    end
    stats = graycoprops(glcmsTrue);
    measurements(a).NucContrast = stats.Contrast;
    measurements(a).NucMeanContrast = mean(stats.Contrast);
    measurements(a).NucMinContrast = min(stats.Contrast);
    measurements(a).NucMaxContrast = max(stats.Contrast);
    measurements(a).NucCVContrast = (std(stats.Contrast) / mean(stats.Contrast));
    measurements(a).NucVarContrast = var(stats.Contrast);
    measurements(a).NucCorrelation = stats.Correlation;
    measurements(a).NucMeanCorrelation = mean(stats.Correlation);
    measurements(a).NucMinCorrelation = min(stats.Correlation);
    measurements(a).NucMaxCorrelation = max(stats.Correlation);
    measurements(a).NucCVCorrelation = (std(stats.Correlation) / mean(stats.Correlation));
    measurements(a).NucVarCorrelation = var(stats.Correlation);
    measurements(a).NucEnergy = stats.Energy;
    measurements(a).NucMeanEnergy = mean(stats.Energy);
    measurements(a).NucMinEnergy = min(stats.Energy);
    measurements(a).NucMaxEnergy = max(stats.Energy);
    measurements(a).NucCVEnergy = (std(stats.Energy) / mean(stats.Energy));
    measurements(a).NucVarEnergy = var(stats.Energy); 
    measurements(a).NucHomogeneity = stats.Homogeneity;
    measurements(a).NucMeanHomogeneity = mean(stats.Homogeneity);
    measurements(a).NucMinHomogeneity = min(stats.Homogeneity);
    measurements(a).NucMaxHomogeneity = max(stats.Homogeneity);
    measurements(a).NucCVHomogeneity = (std(stats.Homogeneity) / mean(stats.Homogeneity));
    measurements(a).NucVarHomogeneity = var(stats.Homogeneity); 
end

%Radial distribution calculations.
for c = 1:length(measurements)
    NucCentroid = measurements(c).NucCentroid;
    [J, I] = ind2sub(size(measurements(c).CellImage), measurements(c).NucOutlinePixels); %J is rows, I is columns (from top left)
    D = pdist2(NucCentroid, [I J], 'euclidean');         %Euclidean distances between nuclear centroid and all perimeter pixels
    maxD = max(D);                                      %maximum distance between nuclear centroid and perimeter
    [Y, X] = ind2sub(size(measurements(c).CellImage), transpose(1:numel(measurements(c).CellImage)));   
    Dall = pdist2(NucCentroid, [X Y], 'euclidean');     %distances between nuclear centroid and ALL pixels in image rectangle
    Disc1Pos = find(Dall < maxD/4);
    disc1 = [];
    nucimage = measurements(c).NucImageNoBG;
    total = sum(sum(measurements(c).NucImageNoBG));    %sum of all intensities within the nucleus (cell and background set to 0)
    for d = 1:length(Disc1Pos)
        disc1 = [disc1 nucimage(Disc1Pos(d))];
    end
    measurements(c).NucFracTotalDisc1 = sum(disc1)/total;
    measurements(c).NucCVDisc1 = std(double(disc1)) / mean(disc1);
    measurements(c).NucVarDisc1 = var(double(disc1));
    Disc2Pos = find(Dall < maxD/2);
    disc2 = [];
    for d = 1:length(Disc2Pos)
        disc2 = [disc2 nucimage(Disc2Pos(d))];
    end
    measurements(c).NucFracTotalDisc2 = sum(disc2)/total;
    measurements(c).NucCVDisc2 = std(double(disc2)) / mean(disc2);
    measurements(c).NucVarDisc2 = var(double(disc2));
    Disc3Pos = find(Dall < maxD*3/4);
    disc3 = [];
    for d = 1:length(Disc3Pos)
        disc3 = [disc3 nucimage(Disc3Pos(d))];
    end
    measurements(c).NucFracTotalDisc3 = sum(disc3)/total;
    measurements(c).NucCVDisc3 = std(double(disc3)) / mean(disc3);
    measurements(c).NucVarDisc3 = var(double(disc3));
    Disc4Pos = find(Dall < maxD);
    disc4 = [];
    for d = 1:length(Disc4Pos)
        disc4 = [disc4 nucimage(Disc4Pos(d))];
    end
    measurements(c).NucFracTotalDisc4 = sum(disc4)/total;
    measurements(c).NucCVDisc4 = std(double(disc4)) / mean(disc4);
    measurements(c).NucVarDisc4 = var(double(disc4));
end

save('WT_nuctexture.mat', 'measurements')