% This algorithm calculates mitochondrial morphology parameters including
% network parameters and texture/spatial distribution measurements.
% Revised 03/02/2017 by Amy Chang (Marshall Lab, UCSF)

load('WT_nuctexture.mat')

for a = 1:length(measurements)
    segmented = imread(measurements(a).SegmentedFilename);
    FITC = segmented(:,:,1);
    cellmask = measurements(a).CellMask;
    FITCnoBG = FITC;
    FITCnoBG(cellmask == 0) = 0;
    thresh = isodata(imadjust(FITCnoBG));
    BW = im2bw(imadjust(FITCnoBG), thresh); 
    figure
    subplot(1,2,1), imshow(imadjust(FITCnoBG)), title('original FITC, adjusted')
    subplot(1,2,2), imshow(BW), title('thresholded with automatic threshold')
    askyesno = sprintf('This is the mitochondria segmentation. Enter 1 to accept or 0 to reject. ');
    yesno = input(askyesno);  
    while yesno == 0
        figure, imshow(mat2gray(FITCnoBG));
        h2 = imcontrast(gca);
        waitfor(h2)
        FITCmanual = getimage(gca);
        threshManual = isodata(imadjust(FITCmanual));
        BW = im2bw(imadjust(FITCmanual), threshManual); 
        figure, imshow(BW)
        askyesno = sprintf('Is the segmentation acceptable? (0 = No, 1 = Yes) ');
        yesno = input(askyesno);
    end
    close all
    L = bwlabel(BW);
    stats = regionprops(L, 'Area', 'Centroid', 'Perimeter', 'PixelIdxList');
    areas = cat(1, stats.Area);
    perimeters = cat(1, stats.Perimeter);
    centroids = [];
    for b = 1:length(stats)
        centroids = [centroids; stats(b).Centroid];
    end
    measurements(a).MitoImage = FITC;
    measurements(a).MitoImageNoBG = FITCnoBG;
    measurements(a).MitoMask = BW;
    measurements(a).MitoPixels = cat(1, stats.PixelIdxList);
    measurements(a).MitoNumber = length(stats);
    measurements(a).MitoSumArea = sum(areas);
    measurements(a).MitoMeanArea = mean(areas);
    measurements(a).MitoMedianArea = median(areas);
    measurements(a).MitoMaxArea = max(areas);
    measurements(a).MitoMinArea = min(areas);
    measurements(a).MitoCVArea = std(areas) / mean(areas);
    measurements(a).MitoVarArea = var(areas);
    measurements(a).MitoCellAreaRatio = sum(areas) / measurements(a).CellArea;
    measurements(a).MitoSumPerimeter = sum(perimeters);
    measurements(a).MitoMeanPerimeter = mean(perimeters);
    measurements(a).MitoMedianPerimeter = median(perimeters);
    measurements(a).MitoMaxPerimeter = max(perimeters);
    measurements(a).MitoMinPerimeter = min(perimeters);
    measurements(a).MitoCVPerimeter = std(perimeters) / mean(perimeters);
    measurements(a).MitoVarPerimeter = var(perimeters);
    measurements(a).MitoCellPerimeterRatio = sum(perimeters) / measurements(a).CellPerimeter;
    weightedcentroids = [];
    for c = 1:length(stats)
        weightedcentroids = [weightedcentroids; stats(c).Centroid*stats(c).Area];
    end
    measurements(a).MitoCentroid = sum(weightedcentroids)/sum(areas);
    measurements(a).MitoCellCentroidDist = pdist2(measurements(a).MitoCentroid, measurements(a).CellCentroid, 'Euclidean');
    measurements(a).MitoNucCentroidDist = pdist2(measurements(a).MitoCentroid, measurements(a).NucCentroid, 'Euclidean');
    skeleton = bwmorph(BW, 'skel', Inf);
    figure
    subplot(1,2,1), imshow(BW), title('segmented mitochondria')
    subplot(1,2,2), imshow(skeleton), title('skeletonized')
    statsskel = regionprops(skeleton, 'Area', 'PixelIdxList');
    skelareas = cat(1, statsskel.Area);
    sumskel = sum(skelareas);
    measurements(a).MitoObjSkelRatio = measurements(a).MitoSumArea / sumskel;
    branchpoints = bwmorph(skeleton, 'branchpoints');
    endpoints = bwmorph(skeleton, 'endpoints');
    measurements(a).MitoNumBranchpoints = sum(sum(branchpoints));
    measurements(a).MitoNumEndpoints = sum(sum(endpoints));
    diff = skeleton - branchpoints;
    mitoFused = zeros(size(FITC));
    mitoFragmented = zeros(size(FITC));
    IdxBranchpoints = find(branchpoints == 1);
    for d = 1:length(stats)
        if isempty(intersect(stats(d).PixelIdxList, IdxBranchpoints)) == 0        %if not empty, there is an intersection, and it is a fused object
            mitoFused(stats(d).PixelIdxList) = 1;
        elseif isempty(intersect(stats(d).PixelIdxList, IdxBranchpoints)) == 1
            mitoFragmented(stats(d).PixelIdxList) = 1;
        end
    end
    figure
    subplot(1,2,1), imshow(mitoFused), title('fused mitochondria');
    subplot(1,2,2), imshow(mitoFragmented), title('fragmented mitochondria');
    measurements(a).MitoFusedMask = mitoFused;
    measurements(a).MitoFragmentedMask = mitoFragmented;
    measurements(a).MitoMaskFull = mitoFused + mitoFragmented;
    LFused = bwlabel(mitoFused);
    statsFused = regionprops(LFused, 'Area');
    areasFused = cat(1, statsFused.Area);
    totalArea = sum(sum(measurements(a).MitoMaskFull));
    measurements(a).MitoNumberFused = length(statsFused);
    measurements(a).MitoMeanFusedArea = mean(areasFused);
    measurements(a).MitoMaxFusedArea = max(areasFused);
    measurements(a).MitoMinFusedArea = min(areasFused);
    measurements(a).MitoCVFusedArea = std(areasFused) / mean(areasFused);
    measurements(a).MitoVarFusedArea = var(areasFused);
    measurements(a).MitoPercentFusedTotalArea = sum(areasFused) / totalArea; 
    LFragmented = bwlabel(mitoFragmented);
    statsFragmented = regionprops(LFragmented, 'Area');
    areasFragmented = cat(1, statsFragmented.Area);
    measurements(a).MitoNumberFragmented = length(statsFragmented);
    measurements(a).MitoMeanFragmentedArea = mean(areasFragmented);
    measurements(a).MitoMaxFragmentedArea = max(areasFragmented);
    measurements(a).MitoMinFragmentedArea = min(areasFragmented);
    measurements(a).MitoCVFragmentedArea = std(areasFragmented) / mean(areasFragmented);
    measurements(a).MitoVarFragmentedArea = var(areasFragmented); 
    measurements(a).MitoRatioFusedFragmented = sum(areasFused) / sum(areasFragmented);
    measurements(a).MitoPercentFragmentedTotalArea = sum(areasFragmented) / totalArea; 
    close all
end

for e = 1:length(measurements)
    cellmask = measurements(e).CellMask;
    mitoImageNoBG = measurements(e).MitoImageNoBG;
    mitoImageFull = mitoImageNoBG;
    mitoImageFull(cellmask == 0) = 65535;               %set bg pixels to 65536 so they show up in (16, 16) of the GSCM; true low bin interacting pixels are revealed in (1,1)
    K = unique(mitoImageNoBG);
    minpixel = K(2);
    maxpixel = max(K);
    offsets = [0 1; -1 1;-1 0;-1 -1];
    glcmsFull = graycomatrix(mitoImageFull, 'NumLevel', 16, 'GrayLimits', [minpixel maxpixel], 'Symmetric', true, 'Offset', offsets);
    glcmsnoBG = graycomatrix(mitoImageNoBG, 'NumLevel', 16, 'GrayLimits', [minpixel maxpixel], 'Symmetric', true, 'Offset', offsets);   
    glcmsTrue = glcmsnoBG;
    for b = 1:4
        glcmsTrue(1,1,b) = glcmsFull(1,1,b);
    end
    stats = graycoprops(glcmsTrue);
    measurements(e).MitoContrast = stats.Contrast;
    measurements(e).MitoMeanContrast = mean(stats.Contrast);
    measurements(e).MitoMinContrast = min(stats.Contrast);
    measurements(e).MitoMaxContrast = max(stats.Contrast);
    measurements(e).MitoCVContrast = (std(stats.Contrast) / mean(stats.Contrast));
    measurements(e).MitoVarContrast = var(stats.Contrast);
    measurements(e).MitoCorrelation = stats.Correlation;
    measurements(e).MitoMeanCorrelation = mean(stats.Correlation);
    measurements(e).MitoMinCorrelation = min(stats.Correlation);
    measurements(e).MitoMaxCorrelation = max(stats.Correlation);
    measurements(e).MitoCVCorrelation = (std(stats.Correlation) / mean(stats.Correlation));
    measurements(e).MitoVarCorrelation = var(stats.Correlation);
    measurements(e).MitoEnergy = stats.Energy;
    measurements(e).MitoMeanEnergy = mean(stats.Energy);
    measurements(e).MitoMinEnergy = min(stats.Energy);
    measurements(e).MitoMaxEnergy = max(stats.Energy);
    measurements(e).MitoCVEnergy = (std(stats.Energy) / mean(stats.Energy));
    measurements(e).MitoVarEnergy = var(stats.Energy); 
    measurements(e).MitoHomogeneity = stats.Homogeneity;
    measurements(e).MitoMeanHomogeneity = mean(stats.Homogeneity);
    measurements(e).MitoMinHomogeneity = min(stats.Homogeneity);
    measurements(e).MitoMaxHomogeneity = max(stats.Homogeneity);
    measurements(e).MitoCVHomogeneity = (std(stats.Homogeneity) / mean(stats.Homogeneity));
    measurements(e).MitoVarHomogeneity = var(stats.Homogeneity); 
end




for f = 1:length(measurements)
    NucCentroid = measurements(f).NucCentroid;
    [J, I] = ind2sub(size(measurements(f).CellImage), measurements(f).MitoPixels); %J is rows, I is columns (from top left)
    D = pdist2(NucCentroid, [I J], 'euclidean');         %Euclidean distances between nuclear centroid and all mitochondria pixels
    maxD = max(D);                                      %maximum distance between nuclear centroid and any mitochondrial object
    [Y, X] = ind2sub(size(measurements(f).CellImage), transpose(1:numel(measurements(f).CellImage)));   
    Dall = pdist2(NucCentroid, [X Y], 'euclidean');     %distances between nuclear centroid and ALL pixels in image rectangle
    Disc1Pos = find(Dall < maxD/4);
    disc1 = [];
    mitoimage = measurements(f).MitoImageNoBG;
    mitoimage(measurements(f).MitoMask == 0) = 0;
    total = sum(sum(mitoimage));    %sum of all intensities within the nucleus (background set to 0)
    for d = 1:length(Disc1Pos)
        disc1 = [disc1 mitoimage(Disc1Pos(d))];
    end
    measurements(f).MitoFracTotalDisc1 = sum(disc1)/total;
    measurements(f).MitoCVDisc1 = std(double(disc1)) / mean(disc1);
    measurements(f).MitoVarDisc1 = var(double(disc1));
    Disc2Pos = find(Dall < maxD/2);
    disc2 = [];
    for d = 1:length(Disc2Pos)
        disc2 = [disc2 mitoimage(Disc2Pos(d))];
    end
    measurements(f).MitoFracTotalDisc2 = sum(disc2)/total;
    measurements(f).MitoCVDisc2 = std(double(disc2)) / mean(disc2);
    measurements(f).MitoVarDisc2 = var(double(disc2));
    Disc3Pos = find(Dall < maxD*3/4);
    disc3 = [];
    for d = 1:length(Disc3Pos)
        disc3 = [disc3 mitoimage(Disc3Pos(d))];
    end
    measurements(f).MitoFracTotalDisc3 = sum(disc3)/total;
    measurements(f).MitoCVDisc3 = std(double(disc3)) / mean(disc3);
    measurements(f).MitoVarDisc3 = var(double(disc3));
    Disc4Pos = find(Dall < maxD);
    disc4 = [];
    for d = 1:length(Disc4Pos)
        disc4 = [disc4 mitoimage(Disc4Pos(d))];
    end
    measurements(f).MitoFracTotalDisc4 = sum(disc4)/total;
    measurements(f).MitoCVDisc4 = std(double(disc4)) / mean(disc4);
    measurements(f).MitoVarDisc4 = var(double(disc4));
end

filename = measurements(f).SegmentedFilename
filesave = strcat('WT_', filename(8:13), '_ALLMEASUREMENTS.mat')
save(filesave, 'measurements')

