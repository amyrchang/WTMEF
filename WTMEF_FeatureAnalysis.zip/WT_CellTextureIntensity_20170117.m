% Algorithm to analyze textural/spatial distribution features of the
% cell/cytoskeleton.
% Revised 03/02/2017 by Amy Chang (Marshall Lab, UCSF)

load('WT_nucsizeshape.mat')

%Textural calculations (Haralick features).

for a = 1:length(measurements)
    CellImage = measurements(a).CellImage;
    CellMask = measurements(a).CellMask;
    CellImageNoBG = CellImage;
    CellImageNoBG(CellMask == 0) = 0;
    measurements(a).CellImageNoBG = CellImageNoBG;
    CellImageFull = CellImage;
    CellImageFull(CellMask == 0) = 65535;                   %set bg pixels to 65536 so they show up in (16, 16) of the GSCM; true low bin interacting pixels are revealed in (1,1)
    K = unique(CellImageNoBG);
    minpixel = K(2);
    maxpixel = max(K);
    offsets = [0 1; -1 1;-1 0;-1 -1];
    glcmsFull = graycomatrix(CellImageFull, 'NumLevel', 16, 'GrayLimits', [minpixel maxpixel], 'Symmetric', true, 'Offset', offsets);
    glcmsnoBG = graycomatrix(CellImageNoBG, 'NumLevel', 16, 'GrayLimits', [minpixel maxpixel], 'Symmetric', true, 'Offset', offsets);   
    glcmsTrue = glcmsnoBG;
    for b = 1:4
        glcmsTrue(1,1,b) = glcmsFull(1,1,b);
    end
    stats = graycoprops(glcmsTrue);
    measurements(a).CellContrast = stats.Contrast;
    measurements(a).CellMeanContrast = mean(stats.Contrast);
    measurements(a).CellMinContrast = min(stats.Contrast);
    measurements(a).CellMaxContrast = max(stats.Contrast);
    measurements(a).CellCVContrast = (std(stats.Contrast) / mean(stats.Contrast));
    measurements(a).CellVarContrast = var(stats.Contrast);
    measurements(a).CellCorrelation = stats.Correlation;
    measurements(a).CellMeanCorrelation = mean(stats.Correlation);
    measurements(a).CellMinCorrelation = min(stats.Correlation);
    measurements(a).CellMaxCorrelation = max(stats.Correlation);
    measurements(a).CellCVCorrelation = (std(stats.Correlation) / mean(stats.Correlation));
    measurements(a).CellVarCorrelation = var(stats.Correlation);
    measurements(a).CellEnergy = stats.Energy;
    measurements(a).CellMeanEnergy = mean(stats.Energy);
    measurements(a).CellMinEnergy = min(stats.Energy);
    measurements(a).CellMaxEnergy = max(stats.Energy);
    measurements(a).CellCVEnergy = (std(stats.Energy) / mean(stats.Energy));
    measurements(a).CelVarEnergy = var(stats.Energy); 
    measurements(a).CellHomogeneity = stats.Homogeneity;
    measurements(a).CellMeanHomogeneity = mean(stats.Homogeneity);
    measurements(a).CellMinHomogeneity = min(stats.Homogeneity);
    measurements(a).CellMaxHomogeneity = max(stats.Homogeneity);
    measurements(a).CellCVHomogeneity = (std(stats.Homogeneity) / mean(stats.Homogeneity));
    measurements(a).CellVarHomogeneity = var(stats.Homogeneity); 
end

%Radial distribution calculations.
for c = 1:length(measurements)
    NucCentroid = measurements(c).NucCentroid;
    [J, I] = ind2sub(size(measurements(c).CellImage), measurements(c).CellOutlinePixels); %J is rows, I is columns (from top left)
    D = pdist2(NucCentroid, [I J], 'euclidean');         %Euclidean distances between nuclear centroid and all perimeter pixels
    maxD = max(D);                                      %maximum distance between nuclear centroid and perimeter
    [Y, X] = ind2sub(size(measurements(c).CellImage), transpose(1:numel(measurements(c).CellImage)));   
    Dall = pdist2(NucCentroid, [X Y], 'euclidean');     %distances between nuclear centroid and ALL pixels in image rectangle
    Disc1Pos = find(Dall < maxD/4);
    disc1 = [];
    cellimage = measurements(c).CellImageNoBG;
    total = sum(sum(measurements(c).CellImageNoBG));    %sum of all intensities within the cell (background set to 0)
    for d = 1:length(Disc1Pos)
        disc1 = [disc1 cellimage(Disc1Pos(d))];
    end
    measurements(c).CellFracTotalDisc1 = sum(disc1)/total;
    measurements(c).CellCVDisc1 = std(double(disc1)) / mean(disc1);
    measurements(c).CellVarDisc1 = var(double(disc1));
    Disc2Pos = find(Dall < maxD/2);
    disc2 = [];
    for d = 1:length(Disc2Pos)
        disc2 = [disc2 cellimage(Disc2Pos(d))];
    end
    measurements(c).CellFracTotalDisc2 = sum(disc2)/total;
    measurements(c).CellCVDisc2 = std(double(disc2)) / mean(disc2);
    measurements(c).CellVarDisc2 = var(double(disc2));
    Disc3Pos = find(Dall < maxD*3/4);
    disc3 = [];
    for d = 1:length(Disc3Pos)
        disc3 = [disc3 cellimage(Disc3Pos(d))];
    end
    measurements(c).CellFracTotalDisc3 = sum(disc3)/total;
    measurements(c).CellCVDisc3 = std(double(disc3)) / mean(disc3);
    measurements(c).CellVarDisc3 = var(double(disc3));
    Disc4Pos = find(Dall < maxD);
    disc4 = [];
    for d = 1:length(Disc4Pos)
        disc4 = [disc4 cellimage(Disc4Pos(d))];
    end
    measurements(c).CellFracTotalDisc4 = sum(disc4)/total;
    measurements(c).CellCVDisc4 = std(double(disc4)) / mean(disc4);
    measurements(c).CellVarDisc4 = var(double(disc4));
end

save('WT_celltexture.mat', 'measurements')


