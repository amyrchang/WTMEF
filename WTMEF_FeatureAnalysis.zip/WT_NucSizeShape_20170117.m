% This is an algorithm to segment the nucleus and run shape/size analyses.
% Revised 03/02/2017 by Amy Chang (Marshall Lab, UCSF)

load('WT_cellsizeshape.mat')

for a = 1:length(measurements)
    filename = measurements(a).OriginalFilename;
    composite = imread(filename);
    DAPI = composite(:,:,3);
    DAPIAdjusted = imadjust(DAPI);
    BW = edge(DAPIAdjusted, 'sobel');
    se90 = strel('line', 6, 90);
    se0 = strel('line', 6, 0);
    BWdilate = imdilate(BW, [se90, se0]);
    BWfill = imfill(BWdilate, 'holes');
    seD = strel('diamond', 1);
    BWsmooth = imerode(BWfill, seD);
    L = bwlabel(BWsmooth);
    stats = regionprops(L, 'Area', 'PixelIdxList');
    areas = cat(1, stats.Area);
    b = find(areas == max(areas));
    BWsmooth_clean = zeros(size(BWsmooth));
    BWsmooth_clean(stats(b).PixelIdxList) = BWsmooth(stats(b).PixelIdxList);
    BWoutline = bwperim(BWsmooth_clean);
    figure
    subplot(1,2,1), imshow(imfuse(measurements(a).CellOutline, DAPIAdjusted)), title('DAPI, contrast adjusted')
    subplot(1,2,2), imshow(imfuse(BWoutline, DAPIAdjusted)), title('segmented')
    askyesno = sprintf('This is the nuclear segmentation. Enter 1 to accept or 0 to reject. ');
    yesno = input(askyesno);  
    while yesno == 0
        figure, imshow(mat2gray(DAPI));
        h2 = imcontrast(gca);
        waitfor(h2)
        DAPImanual = getimage(gca);
        BW = edge(DAPImanual, 'sobel');
        BWdilate = imdilate(BW, [se90, se0]);
        BWfill = imfill(BWdilate, 'holes');
        BWsmooth = imerode(BWfill, seD);
        L = bwlabel(BWsmooth);
        stats = regionprops(L, 'Area', 'PixelIdxList');
        areas = cat(1, stats.Area);
        c = find(areas == max(areas))
        BWsmooth_clean = zeros(size(BWsmooth));
        BWsmooth_clean(stats(c).PixelIdxList) = BWsmooth(stats(c).PixelIdxList);
        BWoutline = bwperim(BWsmooth_clean);
        figure
        subplot(1,2,1), imshow(imfuse(measurements(a).CellOutline, DAPIAdjusted)), title('DAPI, contrast adjusted')
        subplot(1,2,2), imshow(imfuse(BWoutline, DAPIAdjusted)), title('segmented')
        askyesno = sprintf('Is the segmentation acceptable? (0 = No, 1 = Yes) ');
        yesno = input(askyesno);
    end
    measurements(a).NucImage = DAPI;
    nucOutline = zeros(size(DAPI));
    nucOutline(BWoutline) = 65535;
    measurements(a).NucOutline = nucOutline;
    LOutline = bwlabel(nucOutline);
    statsOutline = regionprops(LOutline, 'PixelIdxList');
    measurements(a).NucOutlinePixels = statsOutline.PixelIdxList;
    nucFilled = imfill(nucOutline);
    measurements(a).NucMask = nucFilled;
    figure, imshow(imfuse(measurements(a).CellOutline, DAPIAdjusted))
    nucnumber = input('How many nuclei are there? ');
    measurements(a).NucNumber = nucnumber;
    L_clean = bwlabel(BWsmooth_clean);
    stats_clean = regionprops(L_clean, 'Area', 'Centroid', 'ConvexArea', 'ConvexHull', ...
                                        'ConvexImage', 'Eccentricity', 'EquivDiameter', ...
                                        'MajorAxisLength', 'MinorAxisLength', 'Perimeter', ...
                                        'PixelList', 'Solidity');
    measurements(a).NucArea = stats_clean.Area;
    measurements(a).NucMeanArea = (stats_clean.Area) / nucnumber;
    measurements(a).NucCellAreaRatio = stats_clean.Area / measurements(a).CellArea;
    measurements(a).NucCentroid = stats_clean.Centroid;
    measurements(a).NucCellCentroidDist = pdist2(measurements(a).NucCentroid, measurements(a).CellCentroid, 'Euclidean');
    measurements(a).NucConvexArea = stats_clean.ConvexArea;
    measurements(a).NucConvexHull = stats_clean.ConvexHull;
    measurements(a).NucConvexImage = stats_clean.ConvexImage;
    measurements(a).NucEccentricity = stats_clean.Eccentricity;
    measurements(a).NucEquivDiameterArea = stats_clean.EquivDiameter;
    measurements(a).NucMajorAxisLength = stats_clean.MajorAxisLength;
    measurements(a).NucMinorAxisLength = stats_clean.MinorAxisLength;
    measurements(a).NucPerimeter = stats_clean.Perimeter;
    measurements(a).NucMeanPerimeter = (stats_clean.Perimeter) / nucnumber;
    measurements(a).NucCellPerimeterRatio = stats_clean.Perimeter / measurements(a).CellPerimeter;
    measurements(a).NucPixelList = stats_clean.PixelList;
    measurements(a).NucSolidity = stats_clean.Solidity;
    close all
end


% Calculate parameters not included in the 'regionprops' function of MATLAB.

% Calculate ConvexPerimeter, the perimeter of the convex hull.
for n = 1:length(measurements)
    A = measurements(n).NucConvexImage;
    L = bwlabel(A);
    convexLabel = regionprops(L, 'Perimeter');
    measurements(n).NucConvexPerimeter = convexLabel.Perimeter;
end

% Calculate EquivDiameterPerim, the diameter of an equivalent perimeter circle
for p = 1:length(measurements)
    perimeter = measurements(p).NucPerimeter;     % perimeter of a circle is pi*diameter
    diameter = perimeter / pi;
    measurements(p).NucEquivDiameterPerim = diameter;
end
    
% Calculate ratio between the major axis and minor axis lengths.
for q = 1:length(measurements)
    ratioMajorMinor = (measurements(q).NucMajorAxisLength) / (measurements(q).NucMinorAxisLength);
    measurements(q).NucRatioMajorMinor = ratioMajorMinor;
end

% Calculate the area filled by the nucleus vs area of a circle w/ diameter
% equal to the major axis length (a rough measure of the "circularity" of the object).
for r = 1:length(measurements)
    circleArea = (((measurements(r).NucMajorAxisLength) / 2)^2) * pi;
    measurements(r).NucCircularity = measurements(r).NucArea / circleArea;
end

% Calculate pairwise distances between all perimeter pixels and the nucleus
% centroid. Calculate MeanCentroidDist, MaxCentroidDist, MinCentroidDist, CVCentroidDist, and VarCentroidDist. 
for s = 1:length(measurements)
    [I J] = find(measurements(s).NucOutline > 0);      % convert perimeter pixels to Euclidean coordinates
    centroid = measurements(s).NucCentroid;          % cell centroid
    distances = pdist2([J I], centroid, 'Euclidean');
    measurements(s).NucMeanCentroidDist = mean(distances);
    measurements(s).NucMaxCentroidDist = max(distances);
    measurements(s).NucMinCentroidDist = min(distances);
    measurements(s).NucCVCentroidDist = (std(distances))/(mean(distances));
    measurements(s).NucVarCentroidDist = var(distances);
end

%smoothness/roughness measurements
for t = 1:length(measurements)
    A = measurements(t).NucOutline;
    H1 = fspecial('gaussian', [5 5], 2);
    A1 = imfilter(A, H1);
    A1Thinned = bwmorph(A1, 'thin', inf);
    A1Filled = imfill(A1Thinned, 'holes');
    SE1 = strel('disk', 1);
    A1Eroded = imerode(A1Filled, SE1);
    A1Dilated = imdilate(A1Eroded, SE1);
    L1 = bwlabel(A1Dilated);
    stats1 = regionprops(L1, 'Area', 'Perimeter', 'PixelIdxList');
    u = cat(1, stats1.Area);
    w = find(u == max(u));
    A1Cleaned = zeros(size(A));
    A1Cleaned(stats1(w).PixelIdxList) = 65535;
    figure
    subplot(1,2,1), imshow(A), title('original')
    subplot(1,2,2), imshow(A1Cleaned), title('low smooth')
    askyesno = sprintf('This is the low smoothed outline. Enter 1 to accept. ');   
    yesno = input(askyesno);
    if yesno == 1
        close all
    end
    measurements(t).NucLowSmoothMask = A1Cleaned;
    measurements(t).NucLowSmoothArea = stats1(w).Area;
    measurements(t).NucLowSmoothPerimeter = stats1(w).Perimeter;
    measurements(t).NucLowSmoothOrigAreaChange = (stats1(w).Area - measurements(t).NucArea);
    measurements(t).NucLowSmoothOrigAreaChangeRel = (measurements(t).NucLowSmoothOrigAreaChange / measurements(t).NucArea);
    measurements(t).NucLowSmoothOrigPerimeterChange = (stats1(w).Perimeter - measurements(t).NucPerimeter);
    measurements(t).NucLowSmoothOrigPerimeterChangeRel = (measurements(t).NucLowSmoothOrigPerimeterChange / measurements(t).NucPerimeter);
    measurements(t).NucLowSmoothOrigAreaRatio = (stats1(w).Area / measurements(t).NucArea);
    measurements(t).NucLowSmoothOrigPerimeterRatio = (stats1(w).Perimeter / measurements(t).NucPerimeter);
    H2 = fspecial('gaussian', [10 10], 2);
    A2 = imfilter(A, H2);
    A2Thinned = bwmorph(A2, 'thin', inf);
    A2Filled = imfill(A2Thinned, 'holes');
    SE2 = strel('disk', 1);
    A2Eroded = imerode(A2Filled, SE2);
    A2Dilated = imdilate(A2Eroded, SE2);
    L2 = bwlabel(A2Dilated);
    stats2 = regionprops(L2, 'Area', 'Perimeter', 'PixelIdxList');
    x = cat(1, stats2.Area);
    z = find(x == max(x));
    A2Cleaned = zeros(size(A));
    A2Cleaned(stats2(z).PixelIdxList) = 65535;
    figure
    subplot(1,2,1), imshow(A), title('original')
    subplot(1,2,2), imshow(A2Cleaned), title('high smooth')
    askyesno = sprintf('This is the high smoothed outline. Enter 1 to accept. ');   
    yesno = input(askyesno);
    if yesno == 1
        close all
    end
    measurements(t).NucHighSmoothMask = A2Cleaned;
    measurements(t).NucHighSmoothArea = stats2(z).Area;
    measurements(t).NucHighSmoothPerimeter = stats2(z).Perimeter;
    measurements(t).NucHighSmoothOrigAreaChange = (stats2(z).Area - measurements(t).NucArea);
    measurements(t).NucHighSmoothOrigAreaChangeRel = (measurements(t).NucHighSmoothOrigAreaChange / measurements(t).NucArea);
    measurements(t).NucHighSmoothOrigPerimeterChange = (stats2(z).Perimeter - measurements(t).NucPerimeter);
    measurements(t).NucHighSmoothOrigPerimeterChangeRel = (measurements(t).NucHighSmoothOrigPerimeterChange / measurements(t).NucPerimeter);
    measurements(t).NucHighSmoothOrigAreaRatio = (stats2(z).Area / measurements(t).NucArea);
    measurements(t).NucHighSmoothOrigPerimeterRatio = (stats2(z).Perimeter / measurements(t).NucPerimeter);
end

save('WT_nucsizeshape.mat', 'measurements')





