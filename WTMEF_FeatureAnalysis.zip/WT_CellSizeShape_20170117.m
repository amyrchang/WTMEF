% This is an algorithm to measure various size and shape parameters of the
% input image. Useful primarily for nuclear and cellular analysis.
% Revised 03/02/2017 by Amy Chang (Marshall Lab, UCSF)

directory = cd;
D = dir(directory);
b = zeros(1, length(D));
for a = 1:length(D)
    b(a) = isempty(strfind(D(a).name, 'Type1.tif'));
end

measurements = struct([]);
counter = 0;
for i = 1:length(b)
    if b(i) == 0
        counter = counter + 1;
        measurements(counter).SegmentedFilename = D(i).name;
        temp = D(i).name;
        k = length(temp) - 4;
        temp = temp(1:k);
        measurements(counter).OriginalFilename = strcat(temp, 'original.tif');
        i = i + 1;
    elseif b(i) == 1
        i = i + 1;
    end
end

for m = 1:length(measurements)
    segmented = imread(measurements(m).SegmentedFilename);
    original = imread(measurements(m).OriginalFilename);
    segmentedBlue = segmented(:,:,3);
    originalBlue = original(:,:,3);
    allOutlines = segmentedBlue - originalBlue;
    originalGreen = original(:,:,2);
    measurements(m).CellImage = originalGreen;
    L = bwlabel(allOutlines);
    statsOutline = regionprops(L, 'Area', 'PixelIdxList');
    cellIndex = find([statsOutline.Area] == max([statsOutline.Area]));
    cellOutline = zeros(size(originalBlue));
    cellOutline(statsOutline(cellIndex).PixelIdxList) = 65535;
    figure, imshow(imfuse(imadjust(originalGreen), cellOutline))
    askyesno = sprintf('This is the cell outline. Enter 1 to acknowledge. ');
    yesno = input(askyesno);
    if yesno == 1
        close all
    end
    measurements(m).CellOutline = cellOutline;
    measurements(m).CellOutlinePixels = statsOutline(cellIndex).PixelIdxList;
    cellFilled = imfill(cellOutline);
    measurements(m).CellMask = cellFilled;
    L = bwlabel(cellFilled);
    stats = regionprops(L, 'Area', 'Centroid', 'ConvexArea', 'ConvexHull', ...
                            'ConvexImage', 'Eccentricity', 'EquivDiameter', ...
                            'MajorAxisLength', 'MinorAxisLength', 'Perimeter', ...
                            'PixelList', 'Solidity')
    measurements(m).CellArea = stats.Area;
    measurements(m).CellCentroid = stats.Centroid;
    measurements(m).CellConvexArea = stats.ConvexArea;
    measurements(m).CellConvexHull = stats.ConvexHull;
    measurements(m).CellConvexImage = stats.ConvexImage;
    measurements(m).CellEccentricity = stats.Eccentricity;
    measurements(m).CellEquivDiameterArea = stats.EquivDiameter;
    measurements(m).CellMajorAxisLength = stats.MajorAxisLength;
    measurements(m).CellMinorAxisLength = stats.MinorAxisLength;
    measurements(m).CellPerimeter = stats.Perimeter;
    measurements(m).CellPixelList = stats.PixelList;
    measurements(m).CellSolidity = stats.Solidity;
end

% Calculate parameters not included in the 'regionprops' function of MATLAB.

% Calculate ConvexPerimeter, the perimeter of the convex hull.
for n = 1:length(measurements)
    A = measurements(n).CellConvexImage;
    L = bwlabel(A);
    convexLabel = regionprops(L, 'Perimeter');
    measurements(n).CellConvexPerimeter = convexLabel.Perimeter;
end

% Calculate EquivDiameterPerim, the diameter of an equivalent perimeter circle
for p = 1:length(measurements)
    perimeter = measurements(p).CellPerimeter;     % perimeter of a circle is pi*diameter
    diameter = perimeter / pi;
    measurements(p).CellEquivDiameterPerim = diameter;
end
    
% Calculate ratio between the major axis and minor axis lengths.
for q = 1:length(measurements)
    ratioMajorMinor = (measurements(q).CellMajorAxisLength) / (measurements(q).CellMinorAxisLength);
    measurements(q).CellRatioMajorMinor = ratioMajorMinor;
end

% Calculate the area filled by the cell vs area of a circle w/ diameter
% equal to the major axis length (a rough measure of the "circularity" of the object).
for r = 1:length(measurements)
    circleArea = (((measurements(r).CellMajorAxisLength) / 2)^2) * pi;
    measurements(r).CellCircularity = measurements(r).CellArea / circleArea;
end

% Calculate pairwise distances between all perimeter pixels and the cell
% centroid. Calculate MeanCentroidDist, MaxCentroidDist, MinCentroidDist, CVCentroidDist, and VarCentroidDist. 
for s = 1:length(measurements)
    [I J] = find(measurements(s).CellOutline > 0);      % convert perimeter pixels to Euclidean coordinates
    centroid = measurements(s).CellCentroid;          % cell centroid
    distances = pdist2([J I], centroid, 'Euclidean');
    measurements(s).CellMeanCentroidDist = mean(distances);
    measurements(s).CellMaxCentroidDist = max(distances);
    measurements(s).CellMinCentroidDist = min(distances);
    measurements(s).CellCVCentroidDist = (std(distances))/(mean(distances));
    measurements(s).CellVarCentroidDist = var(distances);
end
  
%smoothness/roughness measurements
for t = 1:length(measurements)
    A = measurements(t).CellOutline;
    H1 = fspecial('gaussian', [10 10], 2);
    A1 = imfilter(A, H1);
    A1Thinned = bwmorph(A1, 'thin', inf);
    A1Filled = imfill(A1Thinned, 'holes');
    SE1 = strel('disk', 1);
    A1Eroded = imerode(A1Filled, SE1);
    A1Dilated = imdilate(A1Eroded, SE1);
    L1 = bwlabel(A1Dilated);
    stats1 = regionprops(L1, 'Area', 'Perimeter', 'PixelIdxList');
    u = cat(1, stats1.Area);
    w = find(u == max(u));
    A1Cleaned = zeros(size(A));
    A1Cleaned(stats1(w).PixelIdxList) = 65535;
    figure
    subplot(1,2,1), imshow(A), title('original')
    subplot(1,2,2), imshow(A1Cleaned), title('low smooth')
    askyesno = sprintf('This is the low smoothed outline. Enter 1 to accept. ');   
    yesno = input(askyesno);
    if yesno == 1
        close all
    end
    measurements(t).CellLowSmoothMask = A1Cleaned;
    measurements(t).CellLowSmoothArea = stats1(w).Area;
    measurements(t).CellLowSmoothPerimeter = stats1(w).Perimeter;
    measurements(t).CellLowSmoothOrigAreaChange = (stats1(w).Area - measurements(t).CellArea);
    measurements(t).CellLowSmoothOrigAreaChangeRel = (measurements(t).CellLowSmoothOrigAreaChange / measurements(t).CellArea);
    measurements(t).CellLowSmoothOrigPerimeterChange = (stats1(w).Perimeter - measurements(t).CellPerimeter);
    measurements(t).CellLowSmoothOrigPerimeterChangeRel = (measurements(t).CellLowSmoothOrigPerimeterChange / measurements(t).CellPerimeter);
    measurements(t).CellLowSmoothOrigAreaRatio = (stats1(w).Area / measurements(t).CellArea);
    measurements(t).CellLowSmoothOrigPerimeterRatio = (stats1(w).Perimeter / measurements(t).CellPerimeter);
    H2 = fspecial('gaussian', [20 20], 2);
    A2 = imfilter(A, H2);
    A2Thinned = bwmorph(A2, 'thin', inf);
    A2Filled = imfill(A2Thinned, 'holes');
    SE2 = strel('disk', 1);
    A2Eroded = imerode(A2Filled, SE2);
    A2Dilated = imdilate(A2Eroded, SE2);
    L2 = bwlabel(A2Dilated);
    stats2 = regionprops(L2, 'Area', 'Perimeter', 'PixelIdxList');
    x = cat(1, stats2.Area);
    z = find(x == max(x));
    A2Cleaned = zeros(size(A));
    A2Cleaned(stats2(z).PixelIdxList) = 65535;
    figure
    subplot(1,2,1), imshow(A), title('original')
    subplot(1,2,2), imshow(A2Cleaned), title('high smooth')
    askyesno = sprintf('This is the high smoothed outline. Enter 1 to accept. ');   
    yesno = input(askyesno);
    if yesno == 1
        close all
    end
    measurements(t).CellHighSmoothMask = A2Cleaned;
    measurements(t).CellHighSmoothArea = stats2(z).Area;
    measurements(t).CellHighSmoothPerimeter = stats2(z).Perimeter;
    measurements(t).CellHighSmoothOrigAreaChange = (stats2(z).Area - measurements(t).CellArea);
    measurements(t).CellHighSmoothOrigAreaChangeRel = (measurements(t).CellHighSmoothOrigAreaChange / measurements(t).CellArea);
    measurements(t).CellHighSmoothOrigPerimeterChange = (stats2(z).Perimeter - measurements(t).CellPerimeter);
    measurements(t).CellHighSmoothOrigPerimeterChangeRel = (measurements(t).CellHighSmoothOrigPerimeterChange / measurements(t).CellPerimeter);
    measurements(t).CellHighSmoothOrigAreaRatio = (stats2(z).Area / measurements(t).CellArea);
    measurements(t).CellHighSmoothOrigPerimeterRatio = (stats2(z).Perimeter / measurements(t).CellPerimeter);
end

close all

save('WT_cellsizeshape.mat', 'measurements')
