% Algorithm to segment and categorize cells, and stitch necessary ones
% (using MIJ ImageJ interface).
% Revised 03/02/2017 by Amy Chang (Marshall Lab, UCSF)

javaaddpath('/Applications/MATLAB_R2014b.app/java/mij.jar')
javaaddpath('/Applications/MATLAB_R2014b.app/java/ij.jar')
MIJ.start('/Applications/ImageJ/ImageJ/ImageJ/plugins')
alphabet = 'ABCDEFGHIJKLMNOP'
column = 1:24
Cy5_7x7 = cell(7);
FITC_7x7 = cell(7);
DAPI_7x7 = cell(7);
DAPI_7x7orig = cell(7);
DAPIlines = zeros(1024, 1024);
for i = 2:length(alphabet);
    for j = 24:length(column);
        for k = 1:49;
            Cy5file = strcat('/Volumes/Fantom HD/20141223/Amy_Chang/Amy_Chang_Chang1_2014.12.24.20.10.07/', alphabet(i), ' -', {' '}, num2str(j), '(fld ', {' '} , num2str(k), ' wv Cy5 - Cy5).tif');
            FITCfile = strcat('/Volumes/Fantom HD/20141223/Amy_Chang/Amy_Chang_Chang1_2014.12.24.20.10.07/', alphabet(i), ' -', {' '}, num2str(j), '(fld ', {' '} , num2str(k), ' wv FITC - FITC).tif');
            DAPIfile = strcat('/Volumes/Fantom HD/20141223/Amy_Chang/Amy_Chang_Chang1_2014.12.24.20.10.07/', alphabet(i), ' -', {' '}, num2str(j), '(fld ', {' '} , num2str(k), ' wv DAPI - DAPI).tif');
            Cy5image = imread(Cy5file{1});
            FITCimage = imread(FITCfile{1});
            DAPIimage = imread(DAPIfile{1});
            Cy5_7x7{k} = Cy5image;
            FITC_7x7{k} = FITCimage;
            DAPI_7x7orig{k} = DAPIimage;
            DAPIlines = DAPIimage;
            DAPIlines(:, 1023) = 1;
            DAPIlines(:, 1024) = 1;                                  % Add line on right side of FOV
            DAPIlines(1023, :) = 1; 
            DAPIlines(1024, :) = 1;                                  % Add line on bottom of FOV
            DAPI_7x7{k} = DAPIlines;       
        end
        DAPImatrixorig = [DAPI_7x7orig{1} DAPI_7x7orig{2} DAPI_7x7orig{3} DAPI_7x7orig{4} DAPI_7x7orig{5} DAPI_7x7orig{6} DAPI_7x7orig{7};
                    DAPI_7x7orig{8} DAPI_7x7orig{9} DAPI_7x7orig{10} DAPI_7x7orig{11} DAPI_7x7orig{12} DAPI_7x7orig{13} DAPI_7x7orig{14};
                    DAPI_7x7orig{15} DAPI_7x7orig{16} DAPI_7x7orig{17} DAPI_7x7orig{18} DAPI_7x7orig{19} DAPI_7x7orig{20} DAPI_7x7orig{21};
                    DAPI_7x7orig{22} DAPI_7x7orig{23} DAPI_7x7orig{24} DAPI_7x7orig{25} DAPI_7x7orig{26} DAPI_7x7orig{27} DAPI_7x7orig{28};
                    DAPI_7x7orig{29} DAPI_7x7orig{30} DAPI_7x7orig{31} DAPI_7x7orig{32} DAPI_7x7orig{33} DAPI_7x7orig{34} DAPI_7x7orig{35};
                    DAPI_7x7orig{36} DAPI_7x7orig{37} DAPI_7x7orig{38} DAPI_7x7orig{39} DAPI_7x7orig{40} DAPI_7x7orig{41} DAPI_7x7orig{42};
                    DAPI_7x7orig{43} DAPI_7x7orig{44} DAPI_7x7orig{45} DAPI_7x7orig{46} DAPI_7x7orig{47} DAPI_7x7orig{48} DAPI_7x7orig{49}];
        Cy5matrix = [Cy5_7x7{1} Cy5_7x7{2} Cy5_7x7{3} Cy5_7x7{4} Cy5_7x7{5} Cy5_7x7{6} Cy5_7x7{7};
                    Cy5_7x7{8} Cy5_7x7{9} Cy5_7x7{10} Cy5_7x7{11} Cy5_7x7{12} Cy5_7x7{13} Cy5_7x7{14};
                    Cy5_7x7{15} Cy5_7x7{16} Cy5_7x7{17} Cy5_7x7{18} Cy5_7x7{19} Cy5_7x7{20} Cy5_7x7{21};
                    Cy5_7x7{22} Cy5_7x7{23} Cy5_7x7{24} Cy5_7x7{25} Cy5_7x7{26} Cy5_7x7{27} Cy5_7x7{28};
                    Cy5_7x7{29} Cy5_7x7{30} Cy5_7x7{31} Cy5_7x7{32} Cy5_7x7{33} Cy5_7x7{34} Cy5_7x7{35};
                    Cy5_7x7{36} Cy5_7x7{37} Cy5_7x7{38} Cy5_7x7{39} Cy5_7x7{40} Cy5_7x7{41} Cy5_7x7{42};
                    Cy5_7x7{43} Cy5_7x7{44} Cy5_7x7{45} Cy5_7x7{46} Cy5_7x7{47} Cy5_7x7{48} Cy5_7x7{49}];
        FITCmatrix = [FITC_7x7{1} FITC_7x7{2} FITC_7x7{3} FITC_7x7{4} FITC_7x7{5} FITC_7x7{6} FITC_7x7{7};
                    FITC_7x7{8} FITC_7x7{9} FITC_7x7{10} FITC_7x7{11} FITC_7x7{12} FITC_7x7{13} FITC_7x7{14};
                    FITC_7x7{15} FITC_7x7{16} FITC_7x7{17} FITC_7x7{18} FITC_7x7{19} FITC_7x7{20} FITC_7x7{21};
                    FITC_7x7{22} FITC_7x7{23} FITC_7x7{24} FITC_7x7{25} FITC_7x7{26} FITC_7x7{27} FITC_7x7{28};
                    FITC_7x7{29} FITC_7x7{30} FITC_7x7{31} FITC_7x7{32} FITC_7x7{33} FITC_7x7{34} FITC_7x7{35};
                    FITC_7x7{36} FITC_7x7{37} FITC_7x7{38} FITC_7x7{39} FITC_7x7{40} FITC_7x7{41} FITC_7x7{42};
                    FITC_7x7{43} FITC_7x7{44} FITC_7x7{45} FITC_7x7{46} FITC_7x7{47} FITC_7x7{48} FITC_7x7{49}];
        DAPImatrix = [DAPI_7x7{1} DAPI_7x7{2} DAPI_7x7{3} DAPI_7x7{4} DAPI_7x7{5} DAPI_7x7{6} DAPI_7x7{7};
                    DAPI_7x7{8} DAPI_7x7{9} DAPI_7x7{10} DAPI_7x7{11} DAPI_7x7{12} DAPI_7x7{13} DAPI_7x7{14};
                    DAPI_7x7{15} DAPI_7x7{16} DAPI_7x7{17} DAPI_7x7{18} DAPI_7x7{19} DAPI_7x7{20} DAPI_7x7{21};
                    DAPI_7x7{22} DAPI_7x7{23} DAPI_7x7{24} DAPI_7x7{25} DAPI_7x7{26} DAPI_7x7{27} DAPI_7x7{28};
                    DAPI_7x7{29} DAPI_7x7{30} DAPI_7x7{31} DAPI_7x7{32} DAPI_7x7{33} DAPI_7x7{34} DAPI_7x7{35};
                    DAPI_7x7{36} DAPI_7x7{37} DAPI_7x7{38} DAPI_7x7{39} DAPI_7x7{40} DAPI_7x7{41} DAPI_7x7{42};
                    DAPI_7x7{43} DAPI_7x7{44} DAPI_7x7{45} DAPI_7x7{46} DAPI_7x7{47} DAPI_7x7{48} DAPI_7x7{49}];
        composite_adjusted = cat(3, imadjust(FITCmatrix), imadjust(Cy5matrix), imadjust(DAPImatrixorig));
        figure, imshow(composite_adjusted)
        Cy5matrix_adjusted = imadjust(Cy5matrix);
        figure, imshow(Cy5matrix_adjusted)
        BW = edge(Cy5matrix_adjusted, 'sobel');
        se90 = strel('line', 6, 90);
        se0 = strel('line', 6, 0);
        BWdil = imdilate(BW, [se90, se0]);
        BWfill = imfill(BWdil, 'holes');
        seD = strel('diamond', 1);
        BWsmooth = imerode(BWfill, seD);
        L = bwlabel(BWsmooth);
        stats = regionprops(L, 'Area');
        areas = cat(1, stats.Area);
        BWsmooth_clean = BWsmooth;
        for m = 1:length(stats);
            if stats(m).Area < 1000
                I = find(L==m);
                for n = 1:length(I);
                    p = I(n);
                    BWsmooth_clean(p) = 0;
                end
            end
        end
        BWoutline = bwperim(BWsmooth_clean);
        %at this point, have the outline of each segmented cell
        %need to present each cell to user to identify whether or not it is
        %an acceptable cell (isolated, single cell) and also figure out
        %which cells span FOVs and need to be stitched
        outline_blue = DAPImatrix;
        outline_blue(BWoutline) = 65535;
        combo_segmented = imfuse(imadjust(Cy5matrix), imadjust(outline_blue));
        figure, imshow(combo_segmented), title(strcat('Well', {' '}, alphabet(i), ' -', {' '}, num2str(j)))
        L_clean = bwlabel(BWsmooth_clean);              %enumerates each object in BWsmooth_clean (each cell)
        stats_clean = regionprops(L_clean, 'Centroid', 'BoundingBox');  %BoundingBox returns the smallest rectangle 
        centroids = cat(1, stats_clean.Centroid);                       %containing the object
        bboxes = cat(1, stats_clean.BoundingBox);
        hold on
        for p = 1:length(centroids);
            text(centroids(p,1), centroids(p,2), num2str(p), 'color' , 'r', 'fontsize', 14)
        end
        hold off
        cellinfo = struct('cellnumber', (1:length(bboxes)).', 'coordinates', bboxes(:, :))
        for u = 1:length(bboxes);
            if floor(cellinfo.coordinates(u,1)) < 11
                left_x = 1;
            else
                left_x = floor(cellinfo.coordinates(u,1)) - 10;
            end
            if floor(cellinfo.coordinates(u,2)) < 11
                upper_y = 1;
            else
                upper_y = floor(cellinfo.coordinates(u,2)) - 10;
            end
            if ceil(cellinfo.coordinates(u,3) + cellinfo.coordinates(u,1)) > 7158
                right_x = 7168;
            else
                right_x = ceil(cellinfo.coordinates(u,3) + cellinfo.coordinates(u,1) + 10);
            end
            if ceil(cellinfo.coordinates(u,4) + cellinfo.coordinates(u,2)) > 7158
                lower_y = 7168;
            else 
                lower_y = ceil(cellinfo.coordinates(u,4) + cellinfo.coordinates(u,2) + 10);
            end
            boxedDAPIlines = outline_blue(upper_y:lower_y, left_x:right_x);
            boxedDAPIorig = DAPImatrixorig(upper_y:lower_y, left_x:right_x);
            boxedFITC = FITCmatrix(upper_y:lower_y, left_x:right_x);
            boxedCy5 = Cy5matrix(upper_y:lower_y, left_x:right_x);
            comboboxedadjusted = cat(3, imadjust(boxedFITC), imadjust(boxedCy5), imadjust(boxedDAPIlines));
            origwith_outline = cat(3, boxedFITC, boxedCy5, boxedDAPIlines);
            orig = cat(3, boxedFITC, boxedCy5, boxedDAPIorig);
            cellnumber = cellinfo.cellnumber(u);
            if cellinfo.coordinates(u,1) < 1;
                category = 5;
                filename = sprintf('/Users/amychang/Documents/Marshall Lab/20170117_NewWTAlgorithms/Plate1_Well%c%d/Plate1_Well%c%d_Cell%d_Type%d.tif', alphabet(i), j, alphabet(i), j, u, category);
                imwrite(origwith_outline, filename)
                filename3 = sprintf('/Users/amychang/Documents/Marshall Lab/20170117_NewWTAlgorithms/Plate1_Well%c%d/Plate1_Well%c%d_Cell%d_Type%doriginal.tif', alphabet(i), j, alphabet(i), j, u, category);
                imwrite(orig, filename3)
            elseif cellinfo.coordinates(u,2) < 1;
                category = 5;
                filename = sprintf('/Users/amychang/Documents/Marshall Lab/20170117_NewWTAlgorithms/Plate1_Well%c%d/Plate1_Well%c%d_Cell%d_Type%d.tif', alphabet(i), j, alphabet(i), j, u, category);
                imwrite(origwith_outline, filename)
                filename3 = sprintf('/Users/amychang/Documents/Marshall Lab/20170117_NewWTAlgorithms/Plate1_Well%c%d/Plate1_Well%c%d_Cell%d_Type%doriginal.tif', alphabet(i), j, alphabet(i), j, u, category);
                imwrite(orig, filename3)
            elseif ceil(cellinfo.coordinates(u,1) + cellinfo.coordinates(u,3)) > 7067
                category = 5;
                filename = sprintf('/Users/amychang/Documents/Marshall Lab/20170117_NewWTAlgorithms/Plate1_Well%c%d/Plate1_Well%c%d_Cell%d_Type%d.tif', alphabet(i), j, alphabet(i), j, u, category);
                imwrite(origwith_outline, filename)
                filename3 = sprintf('/Users/amychang/Documents/Marshall Lab/20170117_NewWTAlgorithms/Plate1_Well%c%d/Plate1_Well%c%d_Cell%d_Type%doriginal.tif', alphabet(i), j, alphabet(i), j, u, category);
                imwrite(orig, filename3)
            elseif ceil(cellinfo.coordinates(u,2) + cellinfo.coordinates(u,4)) > 7067
                category = 5;
                filename = sprintf('/Users/amychang/Documents/Marshall Lab/20170117_NewWTAlgorithms/Plate1_Well%c%d/Plate1_Well%c%d_Cell%d_Type%d.tif', alphabet(i), j, alphabet(i), j, u, category);
                imwrite(origwith_outline, filename)
                filename3 = sprintf('/Users/amychang/Documents/Marshall Lab/20170117_NewWTAlgorithms/Plate1_Well%c%d/Plate1_Well%c%d_Cell%d_Type%doriginal.tif', alphabet(i), j, alphabet(i), j, u, category);
                imwrite(orig, filename3)
            else
                figure, imshow(comboboxedadjusted)
                query = sprintf('This is cell %d. How should it be categorized? ', cellnumber);
                category = input(query);   
                if category == 1;
                    filename = sprintf('/Users/amychang/Documents/Marshall Lab/20170117_NewWTAlgorithms/Plate1_Well%c%d/Plate1_Well%c%d_Cell%d_Type%d.tif', alphabet(i), j, alphabet(i), j, u, category);
                    imwrite(origwith_outline, filename)
                    filename3 = sprintf('/Users/amychang/Documents/Marshall Lab/20170117_NewWTAlgorithms/Plate1_Well%c%d/Plate1_Well%c%d_Cell%d_Type%doriginal.tif', alphabet(i), j, alphabet(i), j, u, category);
                    imwrite(orig, filename3)
                    close
                end
                if category == 2;
                    filename = sprintf('/Users/amychang/Documents/Marshall Lab/20170117_NewWTAlgorithms/Plate1_Well%c%d/Plate1_Well%c%d_Cell%d_Type%d.tif', alphabet(i), j, alphabet(i), j, u, category);
                    imwrite(origwith_outline, filename)
                    filename3 = sprintf('/Users/amychang/Documents/Marshall Lab/20170117_NewWTAlgorithms/Plate1_Well%c%d/Plate1_Well%c%d_Cell%d_Type%doriginal.tif', alphabet(i), j, alphabet(i), j, u, category);
                    imwrite(orig, filename3)
                    yesno = 0;
                    while yesno == 0
                        figure, imshow(mat2gray(boxedCy5))
                        h2 = imcontrast(gca)
                        waitfor(h2)
                        Cy5manual = getimage(gca);
                        BW = edge(Cy5manual, 'sobel');
                        se90 = strel('line', 6, 90);
                        se0 = strel('line', 6, 0);
                        BWdil = imdilate(BW, [se90, se0]);
                        BWfill = imfill(BWdil, 'holes');
                        seD = strel('diamond', 1);
                        BWsmooth = imerode(BWfill, seD);
                        L = bwlabel(BWsmooth);
                        stats = regionprops(L, 'Area');
                        areas = cat(1, stats.Area);
                        BWsmooth_clean = BWsmooth;
                        for m = 1:length(stats);
                            if stats(m).Area < 1000
                                I = find(L==m);
                                for q = 1:length(I);
                                    p = I(q);
                                    BWsmooth_clean(p) = 0;
                                end
                            end
                        end
                        BWoutline2 = bwperim(BWsmooth_clean);
                        outline_blue2 = boxedDAPIorig;
                        outline_blue2(BWoutline2) = 65535;
                        compositeoutlined = cat(3, boxedFITC, boxedCy5, outline_blue2);
                        figure, imshow(imfuse(imadjust(boxedCy5), imadjust(outline_blue2)))
                        askyesno = sprintf('Is the segmentation acceptable? (0 = No, 1 = Yes) ');
                        yesno = input(askyesno);
                    end
                    filename4 = strcat(filename(1:(length(filename)-4)), '_Type1.tif');
                    imwrite(compositeoutlined, filename4)
                    filename5 = strcat(filename(1:(length(filename)-4)), '_Type1original.tif');
                    composite5 = cat(3, boxedFITC, boxedCy5, boxedDAPIorig);
                    imwrite(composite5, filename5)
                    close
                end
                if category == 3;                       %Category 3 means cell spans multiple FOVs and needs to be stitched
                    filename = sprintf('/Users/amychang/Documents/Marshall Lab/20170117_NewWTAlgorithms/Plate1_Well%c%d/Plate1_Well%c%d_Cell%d_Type%d.tif', alphabet(i), j, alphabet(i), j, u, category);
                    imwrite(origwith_outline, filename)
                    filename3 = sprintf('/Users/amychang/Documents/Marshall Lab/20170117_NewWTAlgorithms/Plate1_Well%c%d/Plate1_Well%c%d_Cell%d_Type%doriginal.tif', alphabet(i), j, alphabet(i), j, u, category);
                    imwrite(orig, filename3) 
                    askwhichFOVs = sprintf('Which FOVs need to be stitched? ');
                    whichFOVs = input(askwhichFOVs);
                    askstitch = 0;
                    while askstitch == 0 
                        for z = 1:length(whichFOVs)
                            Cy5filename = strcat('path=[/Volumes/Fantom HD/20141223/Amy_Chang/Amy_Chang_Chang1_2014.12.24.20.10.07/', alphabet(i), ' -', {' '}, num2str(j), '(fld ', {' '} , num2str(whichFOVs(z)), ' wv Cy5 - Cy5).tif]');
                            FITCfilename = strcat('path=[/Volumes/Fantom HD/20141223/Amy_Chang/Amy_Chang_Chang1_2014.12.24.20.10.07/', alphabet(i), ' -', {' '}, num2str(j), '(fld ', {' '} , num2str(whichFOVs(z)), ' wv FITC - FITC).tif]');
                            DAPIfilename = strcat('path=[/Volumes/Fantom HD/20141223/Amy_Chang/Amy_Chang_Chang1_2014.12.24.20.10.07/', alphabet(i), ' -', {' '}, num2str(j), '(fld ', {' '} , num2str(whichFOVs(z)), ' wv DAPI - DAPI).tif]');
                            MIJ.run('Open...', Cy5filename)
                            MIJ.run('Open...', FITCfilename)
                            MIJ.run('Open...', DAPIfilename)
                            MIJ.run('Merge Channels...', strcat('c1=[', alphabet(i), ' -', {' '}, num2str(j), '(fld ', {' '} , num2str(whichFOVs(z)), ' wv FITC - FITC).tif]', 'c2=[', alphabet(i), ' -', {' '}, num2str(j), '(fld ', {' '} , num2str(whichFOVs(z)), ' wv Cy5 - Cy5).tif]', 'c3=[', alphabet(i), ' -', {' '}, num2str(j), '(fld ', {' '} , num2str(whichFOVs(z)), ' wv DAPI - DAPI).tif] create'));
                            A = MIJ.getCurrentImage;
                            A1 = uint16(A(:,:,1));
                            A2 = uint16(A(:,:,2));
                            A3 = uint16(A(:,:,3));
                            filename2 = sprintf('/Users/amychang/Documents/Marshall Lab/20170117_NewWTAlgorithms/Plate1_Well%c%d/Plate1_Well%c%d_FOV%d.tif', alphabet(i), j, alphabet(i), j, whichFOVs(z));
                            imwrite(cat(3,A1,A2,A3), filename2)
                            MIJ.closeAllWindows
                        end
                        for z = 1:length(whichFOVs)
                            filename2 = sprintf('/Users/amychang/Documents/Marshall Lab/20170117_NewWTAlgorithms/Plate1_Well%c%d/Plate1_Well%c%d_FOV%d.tif', alphabet(i), j, alphabet(i), j, whichFOVs(z));
                            MIJ.run('Open...', strcat('path=[', filename2, ']'))
                            askchannels = sprintf('Channels set to tubulin? ');
                            if input(askchannels) == 1
                                MIJ.run('Enhance Contrast', 'saturated=0.35');
                            end
                        end
                        askready = sprintf('FOVs cropped and ready? ');
                        if input(askready) == 1
                            MIJ.run('Pairwise stitching', 'fusion_method=[Linear Blending] check_peaks=100 compute_overlap subpixel_accuracy x=0.0000 y=0.0000 registration_channel_image_1=[Only channel 2] registration_channel_image_2=[Only channel 2]');
                        end
                        askchannels = sprintf('Channels set to tubulin? ');
                        if input(askchannels) == 1
                            MIJ.run('Enhance Contrast', 'saturated=0.35');
                        end
                        askstitch = sprintf('Stitching looks ok? ');
                        askstitch = input(askstitch);
                    end
                    B = MIJ.getCurrentImage;
                    C = uint16(B);
                    composite = cat(3, C(:,:,1), C(:,:,2), C(:,:,3));
                    yesno = 0;
                    while yesno == 0
                        figure, imshow(mat2gray(C(:,:,2)))
                        h2 = imcontrast(gca)
                        waitfor(h2)
                        Cy5manual = getimage(gca);
                        BW = edge(Cy5manual, 'sobel');
                        se90 = strel('line', 6, 90);
                        se0 = strel('line', 6, 0);
                        BWdil = imdilate(BW, [se90, se0]);
                        BWfill = imfill(BWdil, 'holes');
                        seD = strel('diamond', 1);
                        BWsmooth = imerode(BWfill, seD);
                        L = bwlabel(BWsmooth);
                        stats = regionprops(L, 'Area');
                        areas = cat(1, stats.Area);
                        BWsmooth_clean = BWsmooth;
                        for m = 1:length(stats);
                            if stats(m).Area < 1000
                                I = find(L==m);
                                for q = 1:length(I);
                                    p = I(q);
                                    BWsmooth_clean(p) = 0;
                                end
                            end
                        end
                        BWoutline2 = bwperim(BWsmooth_clean);
                        outline_blue2 = C(:,:,3);
                        outline_blue2(BWoutline2) = 65535;
                        compositeoutlined = cat(3, C(:,:,1), C(:,:,2), outline_blue2);
                        figure, imshow(imfuse(imadjust(C(:,:,2)), imadjust(outline_blue2)))
                        askyesno = sprintf('Is the segmentation acceptable? (0 = No, 1 = Yes) ');
                        yesno = input(askyesno);
                    end
                    celloutline = outline_blue2;
                    celloutline(outline_blue2 < 65535) = 0;
                    BWfill = imfill(celloutline);
                    Lfill = bwlabel(BWfill);
                    statsFill = regionprops(Lfill, 'Area', 'Centroid', 'BoundingBox');
                    area = cat(1, statsFill.Area);
                    maxPos = find(area == max(area));
                    rectangleDim = size(BWfill);
                    centroid = statsFill(maxPos).Centroid;
                    bbox = statsFill(maxPos).BoundingBox;
                    if floor(bbox(1,1)) < 11
                        left_x = 1;
                    else
                        left_x = floor(bbox(1,1)) - 10;
                    end
                    if floor(bbox(1,2)) < 11
                        upper_y = 1;
                    else
                        upper_y = floor(bbox(1,2)) - 10;
                    end
                    if ceil(bbox(1,1) + bbox(1,3)) + 10 > (rectangleDim(2) - left_x)
                        right_x = rectangleDim(2);
                    else
                        right_x = ceil(bbox(1,1) + bbox(1,3)) + 10;
                    end
                    if ceil(bbox(1,2) + bbox(1,4)) + 10 > (rectangleDim(1) - upper_y)
                        lower_y = rectangleDim(1);
                    else
                        lower_y = ceil(bbox(1,2) + bbox(1,4)) + 10;
                    end
                    compositeBoxed = cat(3, C(upper_y:lower_y, left_x:right_x, 1), C(upper_y:lower_y, left_x:right_x, 2), outline_blue2(upper_y:lower_y, left_x:right_x));
                    filename4 = strcat(filename3(1:(length(filename)-4)), 'Stitched_Type1.tif');
                    imwrite(compositeBoxed, filename4)
                    filename5 = strcat(filename(1:(length(filename)-4)), 'Stitched_Type1original.tif');
                    composite5 = cat(3, C(upper_y:lower_y, left_x:right_x, 1), C(upper_y:lower_y, left_x:right_x, 2), C(upper_y:lower_y, left_x:right_x, 3));
                    imwrite(composite5, filename5)
                    MIJ.closeAllWindows
                    close
                end
                if  category == 4;
                    filename = sprintf('/Users/amychang/Documents/Marshall Lab/20170117_NewWTAlgorithms/Plate1_Well%c%d/Plate1_Well%c%d_Cell%d_Type%d.tif', alphabet(i), j, alphabet(i), j, u, category);
                    imwrite(origwith_outline, filename)
                    filename3 = sprintf('/Users/amychang/Documents/Marshall Lab/20170117_NewWTAlgorithms/Plate1_Well%c%d/Plate1_Well%c%d_Cell%d_Type%doriginal.tif', alphabet(i), j, alphabet(i), j, u, category);
                    imwrite(orig, filename3)
                    close
                end
                if category == 6;
                    filename = sprintf('/Users/amychang/Documents/Marshall Lab/20170117_NewWTAlgorithms/Plate1_Well%c%d/Plate1_Well%c%d_Cell%d_Type%d.tif', alphabet(i), j, alphabet(i), j, u, category);
                    imwrite(origwith_outline, filename)
                    filename3 = sprintf('/Users/amychang/Documents/Marshall Lab/20170117_NewWTAlgorithms/Plate1_Well%c%d/Plate1_Well%c%d_Cell%d_Type%doriginal.tif', alphabet(i), j, alphabet(i), j, u, category);
                    imwrite(orig, filename3)
                    close
                end
            end
        end
    end
end

 


% CATEGORIES
% 1 = properly segmented, ready for parameterization
% 2 = improperly segmented, needs manual segmentation
% 3 = needs stitching (found at borders of FOVs, overlap is incorrect) 
% 4 = binucleate/overlapping cells, not analysable
% 5 = in contact with edge of well (not useful)
% 6 = crud / not analysable








        
